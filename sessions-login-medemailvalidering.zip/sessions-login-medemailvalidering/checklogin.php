<?php
// Startar upp sessionen
session_start();

// Användare och lösenord för sidan
$user = "test@test.se";
$pass = "123456";

// Hämtar användare och lösenord från formuläret
$checkUser = $_POST['txtUser'];
$checkPass = $_POST['txtPassword'];
?>
<!DOCTYPE html>
<html lang="sv">
<head>
 <title>Sessioner Hem</title>
 <meta charset="utf-8" />
</head>
<body>
<?php
// Kontrollerar sessionen
if($checkUser == $user && $checkPass == $pass){
	$_SESSION['status'] = "ok";
	echo "<p>Du har loggat in, klicka på länken för att gå vidare!</p>";
	echo '<p><a href="home.php">gå till hem</a></p>';
} else{
	echo "<p>Du har inte fyllt i rätt användare och lösenord</p>";
	echo '<p><a href="index.php">Försök igen</a></p>';
}
?>
</body>
</html>