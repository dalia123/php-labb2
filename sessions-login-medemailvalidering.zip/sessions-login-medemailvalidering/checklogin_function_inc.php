<?php
// Startar upp sessionen
session_start();

require("inc_function.php");

?>
<!DOCTYPE HTML>
<html lang="sv">
<head>
 <title>Sessioner Hem</title>
 <meta charset="utf-8" />
</head>
<body>
<?php
// Användare och lösenord för sidan
$strUser = "test@test.se";
$strPass = "123456";

// Hämtar användare och lösenord från formuläret
$checkUser = $_POST['txtUser'];
$checkPass = $_POST['txtPassword'];

// Validerar e-post (med funktion)
checkEmail($checkUser);

// Kontrollerar inloggningen
if($checkUser == $strUser && $checkPass == $strPass){
	$_SESSION['status'] = "ok";
	echo "Grattis, klicka på länken för att gå vidare!";
	echo "<br />";
	echo '<a href="hem.php">gå till hem</a>';
} else{
	echo "Du har inte fyllt i rätt användare och lösenord";
	echo "<br />";
	echo '<a href="index.php">Försök igen</a>';
}
?>
</body>
</html>