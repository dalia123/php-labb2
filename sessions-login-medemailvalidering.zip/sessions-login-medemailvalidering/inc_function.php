<?php

// Funktion som validerar e-post
function checkEmail($email){
	if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
		echo "Detta är ingen korrekt e-post adress";
		exit;
	}
}
?>
